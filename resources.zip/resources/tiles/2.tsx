<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="2" tilewidth="32" tileheight="32" tilecount="12" columns="3">
 <image source="../images/Swamp Background + Objects/3 Objects/Trees/2.png" width="104" height="132"/>
</tileset>
