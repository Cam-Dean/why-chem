<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="1" tilewidth="32" tileheight="32" tilecount="9" columns="3">
 <image source="../images/Swamp Background + Objects/3 Objects/Trees/1.png" width="102" height="103"/>
</tileset>
