<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="3.River" tilewidth="32" tileheight="32" tilecount="50" columns="10">
 <image source="../images/Free/Free/City_Clean/3.River.png" width="320" height="180"/>
</tileset>
