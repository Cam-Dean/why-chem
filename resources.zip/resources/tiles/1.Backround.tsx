<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="1.Backround" tilewidth="32" tileheight="32" tilecount="50" columns="10">
 <image source="../images/Free/Free/Jungle/1.Backround.png" width="320" height="180"/>
</tileset>
