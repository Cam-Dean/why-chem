<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="4.Sidewalk" tilewidth="32" tileheight="32" tilecount="50" columns="10">
 <image source="../images/Free/Free/City_Clean/4.Sidewalk.png" width="320" height="180"/>
 <tile id="10">
  <objectgroup draworder="index" id="2">
   <object id="1" x="20.7895" y="31.7105">
    <polygon points="0,0 3.42105,-5.13158 4.60526,-9.21053 11.7105,-9.34211 11.1842,0.526316"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="11">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0.131579" y="22.3684">
    <polygon points="0,0 9.07895,-7.5 19.3421,-12.2368 29.6053,-11.7105 31.9737,-8.94737"/>
   </object>
   <object id="2" x="0.394737" y="23.0263">
    <polygon points="0,0 -0.526316,8.94737 14.7368,-4.73684"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="12">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="13.2895">
    <polygon points="0,0 1.44737,-2.23684 1.71053,-2.10526 4.21053,-1.31579 5.65789,2.36842 9.60526,-2.5 11.1842,-1.31579 11.0526,2.76316 13.2895,0.263158 15.2632,2.23684 17.8947,1.57895 21.3158,4.07895 23.1579,0.394737 27.2368,0.657895 31.9737,2.89474 28.6842,5.39474 0,5.26316"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="13">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="20.7895">
    <polygon points="0,0 0.131579,11.3158 13.5526,10.9211 10.5263,7.36842 7.63158,1.18421"/>
   </object>
  </objectgroup>
 </tile>
</tileset>
