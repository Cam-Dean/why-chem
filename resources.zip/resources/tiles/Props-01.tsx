<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="Props-01" tilewidth="32" tileheight="32" tilecount="28" columns="4">
 <image source="../images/City Tilesets/Assets/Props-01.png" width="128" height="224"/>
 <tile id="4">
  <objectgroup draworder="index" id="2">
   <object id="1" x="-0.131579" y="31.9737">
    <polygon points="0,0 0.131579,-28.8158 3.42105,-31.1842 29.2105,-31.0526 32.2368,-29.0789 32.2368,-0.394737"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="8">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0.131579" y="0">
    <polygon points="0,0 -0.131579,14.2105 0.789474,16.0526 30.7895,16.0526 32.1053,13.9474 31.9737,-0.263158"/>
   </object>
  </objectgroup>
 </tile>
</tileset>
