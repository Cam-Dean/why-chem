<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="Terrain (32x32)" tilewidth="32" tileheight="32" tilecount="247" columns="19">
 <image source="../images/Sprites + Stone Objects/Sprites/14-TileSets/Terrain (32x32).png" width="608" height="416"/>
 <tile id="0">
  <objectgroup draworder="index" id="3">
   <object id="3" x="0.131579" y="0.263158">
    <polygon points="0,0 -0.263158,31.7105 31.7105,31.5789 31.8421,-0.263158"/>
   </object>
  </objectgroup>
 </tile>
</tileset>
