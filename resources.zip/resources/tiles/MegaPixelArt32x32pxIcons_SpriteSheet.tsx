<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="MegaPixelArt32x32pxIcons_SpriteSheet" tilewidth="32" tileheight="32" tilecount="504" columns="14">
 <image source="../images/MegaPixelArt32x32pxIcons_SpriteSheet/MegaPixelArt32x32pxIcons_SpriteSheet.png" width="448" height="1152"/>
</tileset>
