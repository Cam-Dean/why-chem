<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="5.Ground" tilewidth="32" tileheight="32" tilecount="50" columns="10">
 <image source="../images/Free/Free/Desert/5.Ground.png" width="320" height="180"/>
 <tile id="40">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="23.0263" width="32" height="8.97368"/>
   <object id="8" x="0.131579" y="20.1316" width="2.63158" height="3.02632"/>
   <object id="9" x="2.89474" y="21.1842" width="11.8421" height="1.71053"/>
   <object id="10" x="14.6053" y="22.0395" width="16.4474" height="1.18421"/>
  </objectgroup>
 </tile>
 <tile id="41">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0.131579" y="23.2895">
    <polygon points="0,0 4.86842,-0.131579 4.86842,-1.18421 5.92105,-1.18421 5.92105,-2.10526 8.02632,-2.23684 8.02632,-3.15789 28.0263,-3.28947 27.8947,-2.10526 31.9737,-2.23684 31.8421,8.68421 -0.131579,8.55263"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="42">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="21.1842">
    <polygon points="0,0 3.94737,-0.131579 4.07895,0.789474 23.1579,0.789474 23.1579,0 30.1316,-0.263158 30.1316,-1.18421 32.1053,-1.18421 32.1053,10.7895 -0.131579,10.7895"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="43">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="20">
    <polygon points="0,0 5,0.131579 5,0.921053 13.9474,1.05263 14.0789,1.97368 19.8684,1.97368 20,2.89474 31.0526,3.02632 31.0526,2.23684 31.9737,2.10526 31.8421,11.5789 0,11.7105"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="44">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0.263158" y="22.2368">
    <polygon points="0,0 4.86842,0 4.86842,-1.18421 11.7105,-1.18421 11.5789,-2.23684 20.9211,-2.10526 20.6579,-1.18421 31.9737,-1.18421 31.7105,9.86842 -0.526316,9.86842"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="45">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="21.1842">
    <polygon points="0,0 9.34211,0 9.34211,-1.05263 23.0263,-1.05263 23.0263,-0.131579 28.9474,-0.131579 28.9474,0.921053 32.2368,0.921053 31.9737,10.7895 -0.131579,10.6579"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="46">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0.131579" y="22.1053">
    <polygon points="0,0 4.86842,0 5.13158,1.05263 15.1316,0.921053 15,-0.131579 17.8947,-0.131579 18.0263,-1.18421 31.8421,-1.05263 31.7105,9.60526 -0.131579,9.73684"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="47">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0.263158" y="21.1842">
    <polygon points="0,0 3.68421,-0.263158 3.68421,-0.921053 11.8421,-1.05263 11.8421,-0.263158 31.9737,-0.263158 31.8421,10.7895 -0.131579,10.9211"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="48">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0.131579" y="21.1842">
    <polygon points="0,0 1.84211,-0.131579 1.84211,0.657895 6.71053,0.789474 6.84211,1.84211 10,1.84211 9.86842,0.789474 10.9211,0.921053 10.7895,-0.263158 24.8684,-0.131579 25,0.657895 32.2368,0.921053 31.9737,10.5263 0.131579,10.6579"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="49">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0.131579" y="21.9737">
    <polygon points="0,0 6.97368,0 6.84211,-0.921053 8.94737,-0.921053 8.94737,-1.97368 10.7895,-1.97368 10.9211,-3.15789 18.0263,-2.89474 18.0263,-2.10526 24.0789,-1.97368 23.9474,-2.76316 30,-2.89474 30,-1.97368 31.8421,-1.97368 31.8421,10 -0.263158,10"/>
   </object>
  </objectgroup>
 </tile>
</tileset>
