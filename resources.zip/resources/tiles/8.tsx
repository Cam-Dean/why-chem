<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="8" tilewidth="19" tileheight="24" tilecount="1" columns="1">
 <image source="../images/Industrial + Bookshelves Objects/3 Objects/2 Decoration/8.png" width="19" height="24"/>
</tileset>
