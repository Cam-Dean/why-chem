<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="Idle" tilewidth="46" tileheight="56" tilecount="1" columns="1">
 <image source="../images/Sprites + Stone Objects/Sprites/11-Door/Idle.png" width="46" height="56"/>
</tileset>
