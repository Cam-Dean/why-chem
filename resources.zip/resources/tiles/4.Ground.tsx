<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="4.Ground" tilewidth="32" tileheight="32" tilecount="50" columns="10">
 <image source="../images/Free/Free/Jungle/4.Ground.png" width="320" height="180"/>
 <tile id="40">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="10.5" width="32" height="21.5"/>
  </objectgroup>
 </tile>
 <tile id="41">
  <objectgroup draworder="index" id="2">
   <object id="2" x="0.0526316" y="10.3026" width="32" height="21.5"/>
  </objectgroup>
 </tile>
 <tile id="42">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0.184211" y="10.3026" width="32" height="21.5"/>
  </objectgroup>
 </tile>
 <tile id="43">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0.0526316" y="10.6974" width="32" height="21.5"/>
  </objectgroup>
 </tile>
 <tile id="44">
  <objectgroup draworder="index" id="2">
   <object id="1" x="-0.210526" y="10.1711" width="32" height="21.5"/>
  </objectgroup>
 </tile>
 <tile id="45">
  <objectgroup draworder="index" id="2">
   <object id="1" x="-0.0789474" y="10.4342" width="32" height="21.5"/>
  </objectgroup>
 </tile>
 <tile id="46">
  <objectgroup draworder="index" id="2">
   <object id="1" x="-0.0789474" y="10.4342" width="32" height="21.5"/>
  </objectgroup>
 </tile>
 <tile id="47">
  <objectgroup draworder="index" id="2">
   <object id="1" x="-0.0789474" y="10.1711" width="32" height="21.5"/>
  </objectgroup>
 </tile>
 <tile id="48">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0.0526316" y="10.3026" width="32" height="21.5"/>
  </objectgroup>
 </tile>
 <tile id="49">
  <objectgroup draworder="index" id="2">
   <object id="1" x="-0.210526" y="10.6974" width="32" height="21.5"/>
  </objectgroup>
 </tile>
</tileset>
